
name = "Topsis_Tewatia/Topsis_Tewatia"
__version__ = "1.0.0"
__author__ = 'Yash Kumar Tewatia'
__credits__ = 'Thapar Institute of Engineering and Technology'
